<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Saad Top Up - সাদ টপআপ ওয়েবসাইট</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header class="main-header">
        <h1>🔥 Saad Top Up (সাদ টপআপ) 🔥</h1>
        <p>ফ্রি ফায়ার, পাবজি এবং সকল গেমের ডায়মন্ড ও ইউসি টপআপের বিশ্বস্ত ঠিকানা</p>
    </header>
    <main class="container">
        <div class="card-grid">
            <div class="game-card">
                <h2>Free Fire Diamond</h2>
                <p>ইনস্ট্যান্ট আইডি কোড টপআপ</p>
                <a href="user/freefire.php" class="btn">টপআপ করুন</a>
            </div>
            <div class="game-card">
                <h2>PUBG Mobile UC</h2>
                <p>দ্রুত এবং নিরাপদ ইউসি টপআপ</p>
                <a href="user/pubg.php" class="btn">টপআপ করুন</a>
            </div>
        </div>
    </main>
    <footer>
        <p>&copy; 2026 Saad Top Up | All Rights Reserved</p>
    </footer>
</body>
</html>
