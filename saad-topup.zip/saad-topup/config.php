<?php
define('SITE_NAME', 'Saad Top Up');
define('SITE_TAG', 'সাদ টপআপ প্ল্যাটফর্ম - ফ্রি ফায়ার ও পাবজি');
$conn = ["status" => "Connected", "db" => "saad_topup_db"];
?>
