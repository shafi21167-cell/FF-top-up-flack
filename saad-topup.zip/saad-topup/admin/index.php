<?php
include '../config.php';
?>
<!DOCTYPE html>
<html lang="bn">
<head>
    <meta charset="UTF-8">
    <title>Saad Top Up - Admin Panel</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body class="admin-body">
    <div class="admin-container">
        <h1>👑 Saad Top Up Admin Dashboard</h1>
        <div class="stats-grid">
            <div class="stat-box"><h3>মোট অর্ডার</h3><p>৫০+</p></div>
            <div class="stat-box"><h3>মোট ইউজার</h3><p>১৫০</p></div>
            <div class="stat-box"><h3>টোটাল ব্যালেন্স</h3><p>১০,০০০৳</p></div>
        </div>
        <br>
        <a href="../index.php" class="btn">ওয়েবসাইটে ফিরে যান</a>
    </div>
</body>
</html>
