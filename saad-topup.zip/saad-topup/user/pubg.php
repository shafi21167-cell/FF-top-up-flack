<?php include '../config.php'; ?>
<!DOCTYPE html>
<html lang="bn">
<head><title>PUBG UC Topup - Saad Top Up</title><link rel="stylesheet" href="../assets/css/style.css"></head>
<body style="padding: 30px; text-align: center;">
    <h2>🛡️ PUBG Mobile UC Topup</h2>
    <form style="max-width: 400px; margin: auto;">
        <input type="text" placeholder="PUBG Character ID" style="width: 100%; padding: 10px; margin: 10px 0;"><br>
        <select style="width: 100%; padding: 10px; margin: 10px 0;">
            <option>60 UC - ১০০ টাকা</option>
            <option>325 UC - ৫০০ টাকা</option>
            <option>660 UC - ১০০০ টাকা</option>
        </select><br>
        <button type="submit" class="btn">অর্ডার কনফার্ম করুন</button>
    </form>
    <br><a href="../index.php" class="btn" style="background:#555;">হোম পেজে ফিরে যান</a>
</body>
</html>
